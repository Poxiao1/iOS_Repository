//
//  ReaderApp.swift
//  Shared
//
//  Created by mac on 2022/8/4.

import SwiftUI

@main
struct ReaderApp: App {
    
    let motionManager = MotionManager()
    let CloudDataManager = CloudData.shared
    
    var body: some Scene {
        WindowGroup {
            Group{
                TabView{
                    Master()
                        .environmentObject(motionManager)
                        .tabItem{
                            Label("阅读列表",systemImage: "books.vertical")
                        }
                    ReadingNote()
                        .tabItem{
                            Label("笔记",systemImage: "note.text")
                        }
                    CheckIn()
                        .environment(\.managedObjectContext, CloudDataManager.container.viewContext)
                        .tabItem {
                            Label("签到", systemImage: "mappin.and.ellipse")
                            
                        }
                }
            }
        }
    }
}

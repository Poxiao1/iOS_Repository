//
//  Master.swift
//  Shared
//
//  Created by mac on 2022/8/4.


import SwiftUI


// View

struct Master: View {
    
    @StateObject var data = TabReadingData()
    
    @AppStorage("darkMode") var darkMode = false
    
    var body: some View{
        NavigationView{
            List(data.articles){
                article in
                NavigationLink(destination: Detail(article: article)){
                    Row(article: article)
                }
                
            }
            .navigationTitle("今日推荐")
            .toolbar{
                
                Setting(darkMode: $darkMode)
            }
        }
        .preferredColorScheme(darkMode ? .dark : .light)
        
    }
}


struct Master_Previews: PreviewProvider {
    static var previews: some View {
        Master()
    }
}

struct ExtractedView: View {
    var body: some View {
        Master()
    }
}
